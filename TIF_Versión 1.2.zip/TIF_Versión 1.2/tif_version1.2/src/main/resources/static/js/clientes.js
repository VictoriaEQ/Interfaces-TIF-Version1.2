const formCliente = document.getElementById("formCliente");
const tablaClientes = document.getElementById("tablaClientes").querySelector("tbody");

// Función para obtener clientes y mostrarlos
async function cargarClientes() {
    tablaClientes.innerHTML = "";
    const res = await fetch("/clientes/traer");
    const clientes = await res.json();

    clientes.forEach(c => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${c.idCliente}</td>
            <td>${c.nombre}</td>
            <td>${c.apellido || ''}</td>
            <td>${c.email || ''}</td>
            <td>${c.telefono || ''}</td>
            <td>${c.direccion || ''}</td>
        `;
        tablaClientes.appendChild(tr);
    });
}

// Función para crear cliente
formCliente.addEventListener("submit", async (e) => {
    e.preventDefault();

    const cliente = {
        nombre: document.getElementById("nombre").value,
        apellido: document.getElementById("apellido").value,
        email: document.getElementById("email").value,
        telefono: document.getElementById("telefono").value,
        direccion: document.getElementById("direccion").value
    };

    const res = await fetch("/clientes/crear", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(cliente)
    });

    const mensaje = await res.text();
    alert(mensaje);

    formCliente.reset();
    cargarClientes();
});

// Cargar clientes al inicio
cargarClientes();
