document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const usuario = document.getElementById('usuario').value;
    const password = document.getElementById('password').value;

    if (usuario === 'admin' && password === '1234') {
        window.location.href = '/admin/productos';
    } else {
        document.getElementById('mensaje').textContent =
            'Usuario o contraseña incorrectos';
    }
});