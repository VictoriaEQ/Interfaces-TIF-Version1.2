package ar.edu.centro8.daw.tif_version12.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "facturas")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Factura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_factura")
    private Long idFactura;

    private LocalDate fecha;

    @PrePersist
    public void prePersist() {
        if (fecha == null) fecha = LocalDate.now();
    }

    private double total;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "id_cliente", nullable = false)
    private Cliente cliente;

    @OneToMany(mappedBy = "factura", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private Set<DetalleFactura> detalles = new HashSet<>();
}