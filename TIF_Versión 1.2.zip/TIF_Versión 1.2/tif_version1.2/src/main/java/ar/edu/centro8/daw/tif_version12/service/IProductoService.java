package ar.edu.centro8.daw.tif_version12.service;

import ar.edu.centro8.daw.tif_version12.model.Producto;

import java.util.List;

public interface IProductoService {

    List<Producto> getProductos();

    Producto findProducto(Long id);

    void saveProducto(Producto producto);

    void deleteProducto(Long id);

    void editProducto(Long id, Producto productoActualizado);

    // Métodos adicionales de negocio si querés luego
}