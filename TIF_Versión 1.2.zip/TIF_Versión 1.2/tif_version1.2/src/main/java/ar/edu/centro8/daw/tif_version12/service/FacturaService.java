package ar.edu.centro8.daw.tif_version12.service;

import ar.edu.centro8.daw.tif_version12.model.Factura;
import ar.edu.centro8.daw.tif_version12.repository.FacturaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FacturaService implements IFacturaService {

    @Autowired
    private FacturaRepository facturaRepo;

    @Override
    public List<Factura> getFacturas() {
        return facturaRepo.findAll();
    }

    @Override
    public Factura findFactura(Long id) {
        return facturaRepo.findById(id).orElse(null);
    }

    @Override
    public void saveFactura(Factura factura) {

        if (factura.getFecha() == null) {
            throw new RuntimeException("La fecha no puede ser nula.");
        }

        if (factura.getTotal() < 0) {
            throw new RuntimeException("El total no puede ser negativo.");
        }

        if (factura.getCliente() == null) {
            throw new RuntimeException("La factura debe tener un cliente asociado.");
        }

        facturaRepo.save(factura);
    }

    @Override
    public void deleteFactura(Long id) {
        facturaRepo.deleteById(id);
    }

    @Override
    public void updateFactura(Long id, Factura facturaActualizada) {

        Factura existente = facturaRepo.findById(id).orElse(null);
        if (existente == null) return;

        if (facturaActualizada.getFecha() == null) {
            throw new RuntimeException("La fecha no puede ser nula.");
        }

        if (facturaActualizada.getTotal() < 0) {
            throw new RuntimeException("El total no puede ser negativo.");
        }

        if (facturaActualizada.getCliente() == null) {
            throw new RuntimeException("La factura debe tener un cliente asociado.");
        }

        existente.setFecha(facturaActualizada.getFecha());
        existente.setTotal(facturaActualizada.getTotal());
        existente.setCliente(facturaActualizada.getCliente());

        facturaRepo.save(existente);
    }
}