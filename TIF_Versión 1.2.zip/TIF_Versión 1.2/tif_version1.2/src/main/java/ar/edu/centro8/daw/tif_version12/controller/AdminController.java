package ar.edu.centro8.daw.tif_version12.controller;

import ar.edu.centro8.daw.tif_version12.model.LoginForm;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AdminController {

    @GetMapping("/admin/dashboard")
    public String dashboard() {
        return "admin/dashboard";
    }

    @GetMapping("/admin/login")
    public String loginPage(Model model) {
        model.addAttribute("loginForm", new LoginForm());
        return "admin/login";
    }

    @PostMapping("/admin/login")
    public String procesarLogin(
            @ModelAttribute LoginForm loginForm,
            RedirectAttributes redirectAttributes
    ) {

        if (loginForm.getUsuario().equals("admin") &&
            loginForm.getPassword().equals("1234")) {
        return "redirect:/admin/dashboard";
        }

        redirectAttributes.addFlashAttribute("mensaje", "Usuario o contraseña incorrectos");
        redirectAttributes.addFlashAttribute("exito", false);

        return "redirect:/admin/login";
    }
}