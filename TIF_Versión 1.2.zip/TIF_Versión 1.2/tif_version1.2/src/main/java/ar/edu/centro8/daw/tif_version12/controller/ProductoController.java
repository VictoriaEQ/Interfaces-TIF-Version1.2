package ar.edu.centro8.daw.tif_version12.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import ar.edu.centro8.daw.tif_version12.model.Producto;
import ar.edu.centro8.daw.tif_version12.service.IProductoService;
import jakarta.validation.Valid;

@RestController
@CrossOrigin(origins = "*", methods= {RequestMethod.GET,RequestMethod.POST, RequestMethod.PUT,RequestMethod.DELETE})
public class ProductoController {

    @Autowired
    private IProductoService productoServ;

    // http://localhost:8080/productos/traer
    @GetMapping("/productos/traer")
    public List<Producto> getProductos() {
        return productoServ.getProductos();
    }

    // http://localhost:8080/productos/traer/1
    @GetMapping("/productos/traer/{id}")
    public Producto traerUnProducto(@PathVariable Long id){
        return productoServ.findProducto(id);
    }

    // http://localhost:8080/productos/crear
    @PostMapping("/productos/crear")
    public String saveProducto(@Valid @RequestBody Producto producto) {
        productoServ.saveProducto(producto);
        return "Se guardó correctamente el registro del producto ingresado.";
    }

    // http://localhost:8080/productos/borrar/1
    @DeleteMapping("/productos/borrar/{id}")
    public String deleteProducto(@PathVariable Long id) {
        productoServ.deleteProducto(id);
        return "El registro del producto seleccionado fue eliminado correctamente.";
    }

    // http://localhost:8080/productos/editar/1
    @PutMapping("/productos/editar/{id}")
    public Producto editProducto(
            @PathVariable Long id,
            @Valid @RequestBody Producto productoActualizado) {
        productoServ.editProducto(id, productoActualizado);
        return productoServ.findProducto(id);
    }
}