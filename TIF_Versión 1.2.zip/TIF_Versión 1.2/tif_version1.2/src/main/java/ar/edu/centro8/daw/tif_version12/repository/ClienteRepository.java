package ar.edu.centro8.daw.tif_version12.repository;

import ar.edu.centro8.daw.tif_version12.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Long> {
}