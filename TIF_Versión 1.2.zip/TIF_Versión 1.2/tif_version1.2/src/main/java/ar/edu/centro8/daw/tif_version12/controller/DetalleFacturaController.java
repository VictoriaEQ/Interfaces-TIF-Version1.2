package ar.edu.centro8.daw.tif_version12.controller;

import ar.edu.centro8.daw.tif_version12.model.DetalleFactura;
import ar.edu.centro8.daw.tif_version12.service.IDetalleFacturaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/detalles")
public class DetalleFacturaController {

    @Autowired
    private IDetalleFacturaService detalleServ;

    @GetMapping("/traer")
    public List<DetalleFactura> getDetalles() {
        return detalleServ.getDetalles();
    }

    @GetMapping("/traer/{id}")
    public DetalleFactura getDetalle(@PathVariable Long id) {
        return detalleServ.findDetalle(id);
    }
}