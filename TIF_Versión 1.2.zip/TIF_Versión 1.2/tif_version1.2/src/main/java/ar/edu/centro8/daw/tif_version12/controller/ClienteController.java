package ar.edu.centro8.daw.tif_version12.controller;

import ar.edu.centro8.daw.tif_version12.model.Cliente;
import ar.edu.centro8.daw.tif_version12.service.IClienteService;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/clientes")
public class ClienteController {

    @Autowired
    private IClienteService clienteServ;

    @GetMapping("/traer")
    public List<Cliente> getClientes() {
        return clienteServ.getClientes();
    }

    @GetMapping("/traer/{id}")
    public Cliente getCliente(@PathVariable Long id) {
        return clienteServ.findCliente(id);
    }

    @PostMapping("/crear")
    public String saveCliente(@Valid @RequestBody Cliente cliente) {
        clienteServ.saveCliente(cliente);
        return "Se guardó correctamente el registro del cliente ingresado.";
    }
}