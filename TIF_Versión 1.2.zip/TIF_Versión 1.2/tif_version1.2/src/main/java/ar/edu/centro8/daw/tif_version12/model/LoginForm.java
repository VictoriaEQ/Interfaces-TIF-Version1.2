package ar.edu.centro8.daw.tif_version12.model;

public class LoginForm {
    private String usuario;
    private String password;

    public LoginForm() {}

    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}