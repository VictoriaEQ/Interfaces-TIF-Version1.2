package ar.edu.centro8.daw.tif_version12.repository;

import ar.edu.centro8.daw.tif_version12.model.Factura;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FacturaRepository extends JpaRepository<Factura, Long> {


    // Más adelante podrías agregar:
    // findByClienteId
    // findByFechaBetween
}