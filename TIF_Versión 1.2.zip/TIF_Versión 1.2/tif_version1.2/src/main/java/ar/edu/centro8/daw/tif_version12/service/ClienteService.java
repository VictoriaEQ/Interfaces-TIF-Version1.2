package ar.edu.centro8.daw.tif_version12.service;

import ar.edu.centro8.daw.tif_version12.model.Cliente;
import ar.edu.centro8.daw.tif_version12.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ClienteService implements IClienteService {

    @Autowired
    private ClienteRepository clienteRepo;

    @Override
    public List<Cliente> getClientes() {
        return clienteRepo.findAll();
    }

    @Override
    public Cliente findCliente(Long id) {
        return clienteRepo.findById(id).orElse(null);
    }

    @Override
    public void saveCliente(Cliente cliente) {

        if (cliente.getNombre() == null || cliente.getNombre().isEmpty()) {
            throw new RuntimeException("El nombre no puede estar vacío.");
        }

        if (cliente.getApellido() == null || cliente.getApellido().isEmpty()) {
            throw new RuntimeException("El apellido no puede estar vacío.");
        }

        if (cliente.getEmail() == null || cliente.getEmail().isEmpty()) {
            throw new RuntimeException("El email no puede estar vacío.");
        }

        clienteRepo.save(cliente);
    }

    @Override
    public void deleteCliente(Long id) {
        clienteRepo.deleteById(id);
    }

    @Override
    public void updateCliente(Long id, Cliente clienteActualizado) {

        Cliente existente = clienteRepo.findById(id).orElse(null);
        if (existente == null) return;

        if (clienteActualizado.getNombre() == null || clienteActualizado.getNombre().isEmpty()) {
            throw new RuntimeException("El nombre no puede estar vacío.");
        }

        if (clienteActualizado.getApellido() == null || clienteActualizado.getApellido().isEmpty()) {
            throw new RuntimeException("El apellido no puede estar vacío.");
        }

        if (clienteActualizado.getEmail() == null || clienteActualizado.getEmail().isEmpty()) {
            throw new RuntimeException("El email no puede estar vacío.");
        }

        existente.setNombre(clienteActualizado.getNombre());
        existente.setApellido(clienteActualizado.getApellido());
        existente.setEmail(clienteActualizado.getEmail());
        existente.setTelefono(clienteActualizado.getTelefono());

        clienteRepo.save(existente);
    }
}
