package ar.edu.centro8.daw.tif_version12.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.*;

@Entity
@Table(name = "productos")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_producto")
    private Long idProducto;

    @NotBlank(message = "El nombre del producto es obligatorio.")
    @Column(nullable = false)
    private String nombre;

    @Positive(message = "El precio debe ser mayor a 0.")
    private double precio;

    @PositiveOrZero(message = "El stock no puede ser negativo.")
    private int stock;

    private String descripcion;

    //NO SE CREA LA RELACIÓN INVERSA HACIA DetalleFactura PARA EVITAR RECURSIVIDAD.
}