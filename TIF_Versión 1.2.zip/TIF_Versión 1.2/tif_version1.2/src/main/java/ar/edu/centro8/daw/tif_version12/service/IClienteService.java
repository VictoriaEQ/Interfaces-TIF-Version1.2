package ar.edu.centro8.daw.tif_version12.service;

import ar.edu.centro8.daw.tif_version12.model.Cliente;

import java.util.List;

public interface IClienteService {

    List<Cliente> getClientes();

    Cliente findCliente(Long id);

    void saveCliente(Cliente cliente);

    void deleteCliente(Long id);

    void updateCliente(Long id, Cliente clienteActualizado);
}
