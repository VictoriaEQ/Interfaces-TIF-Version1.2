package ar.edu.centro8.daw.tif_version12.service;

import ar.edu.centro8.daw.tif_version12.model.Factura;

import java.util.List;

public interface IFacturaService {

    List<Factura> getFacturas();

    Factura findFactura(Long id);

    void saveFactura(Factura factura);

    void deleteFactura(Long id);

    void updateFactura(Long id, Factura facturaActualizada);
}