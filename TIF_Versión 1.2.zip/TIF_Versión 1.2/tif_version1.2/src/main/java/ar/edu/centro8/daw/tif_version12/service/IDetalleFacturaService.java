package ar.edu.centro8.daw.tif_version12.service;

import ar.edu.centro8.daw.tif_version12.model.DetalleFactura;

import java.util.List;

public interface IDetalleFacturaService {

    List<DetalleFactura> getDetalles();

    DetalleFactura findDetalle(Long id);

    void saveDetalle(DetalleFactura detalle);

    void deleteDetalle(Long id);

    void updateDetalle(Long id, DetalleFactura detalleActualizado);
}