package ar.edu.centro8.daw.tif_version12.service;

import ar.edu.centro8.daw.tif_version12.model.Producto;
import ar.edu.centro8.daw.tif_version12.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductoService implements IProductoService {

    @Autowired
    private ProductoRepository productoRepo;

    @Override
    public List<Producto> getProductos() {
        return productoRepo.findAll();
    }

    @Override
    public Producto findProducto(Long id) {
        return productoRepo.findById(id).orElse(null);
    }

    @Override
    public void saveProducto(Producto producto) {

        // Precio no puede ser negativo.
        if (producto.getPrecio() <= 0) {
            throw new RuntimeException("El precio debe ser mayor a 0.");
        }

        // Stock puede ser cero pero no negativo.
        if (producto.getStock() < 0) {
            throw new RuntimeException("El stock no puede ser negativo.");
        }

        productoRepo.save(producto);
    }

    @Override
    public void deleteProducto(Long id) {
        productoRepo.deleteById(id);
    }

    @Override
    public void editProducto(Long id, Producto productoActualizado) {

        Producto existente = productoRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado."));

        if (productoActualizado.getPrecio() <= 0) {
            throw new RuntimeException("El precio debe ser mayor a 0.");
        }

        if (productoActualizado.getStock() < 0) {
            throw new RuntimeException("El stock no puede ser negativo.");
        }

        existente.setNombre(productoActualizado.getNombre());
        existente.setPrecio(productoActualizado.getPrecio());
        existente.setStock(productoActualizado.getStock());
        existente.setDescripcion(productoActualizado.getDescripcion());

        productoRepo.save(existente);
    }
}