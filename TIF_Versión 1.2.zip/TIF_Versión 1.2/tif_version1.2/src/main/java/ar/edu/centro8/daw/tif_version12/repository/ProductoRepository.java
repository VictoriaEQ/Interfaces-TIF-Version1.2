package ar.edu.centro8.daw.tif_version12.repository;

import ar.edu.centro8.daw.tif_version12.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {

    // 1) Buscar productos por coincidencia parcial en el nombre (insensible a mayúsculas)
    List<Producto> findByNombreContainingIgnoreCase(String nombre);

    // 2) Buscar productos dentro de un rango de precios
    List<Producto> findByPrecioBetween(double min, double max);
}