package ar.edu.centro8.daw.tif_version12.service;

import ar.edu.centro8.daw.tif_version12.model.DetalleFactura;
import ar.edu.centro8.daw.tif_version12.repository.DetalleFacturaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class DetalleFacturaService implements IDetalleFacturaService {

    @Autowired
    private DetalleFacturaRepository detalleRepo;

    @Override
    public List<DetalleFactura> getDetalles() {
        return detalleRepo.findAll();
    }

    @Override
    public DetalleFactura findDetalle(Long id) {
        return detalleRepo.findById(id).orElse(null);
    }

    @Override
    public void saveDetalle(DetalleFactura detalle) {

        if (detalle.getCantidad() < 0) {
            throw new RuntimeException("La cantidad no puede ser negativa.");
        }

        if (detalle.getSubtotal() < 0) {
            throw new RuntimeException("El subtotal no puede ser negativo.");
        }

        if (detalle.getProducto() == null) {
            throw new RuntimeException("Debe asociar un producto.");
        }

        if (detalle.getFactura() == null) {
            throw new RuntimeException("Debe asociar una factura.");
        }

        detalleRepo.save(detalle);
    }

    @Override
    public void deleteDetalle(Long id) {
        detalleRepo.deleteById(id);
    }

    @Override
    public void updateDetalle(Long id, DetalleFactura detalleActualizado) {

        DetalleFactura existente = detalleRepo.findById(id).orElse(null);
        if (existente == null) return;

        if (detalleActualizado.getCantidad() < 0) {
            throw new RuntimeException("La cantidad no puede ser negativa.");
        }

        if (detalleActualizado.getSubtotal() < 0) {
            throw new RuntimeException("El subtotal no puede ser negativo.");
        }

        if (detalleActualizado.getProducto() == null) {
            throw new RuntimeException("Debe asociar un producto.");
        }

        if (detalleActualizado.getFactura() == null) {
            throw new RuntimeException("Debe asociar una factura.");
        }

        existente.setCantidad(detalleActualizado.getCantidad());
        existente.setSubtotal(detalleActualizado.getSubtotal());
        existente.setProducto(detalleActualizado.getProducto());
        existente.setFactura(detalleActualizado.getFactura());

        detalleRepo.save(existente);
    }


}