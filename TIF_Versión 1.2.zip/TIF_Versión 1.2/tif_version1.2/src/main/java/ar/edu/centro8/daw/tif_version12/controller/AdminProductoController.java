package ar.edu.centro8.daw.tif_version12.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import ar.edu.centro8.daw.tif_version12.model.Producto;
import ar.edu.centro8.daw.tif_version12.service.IProductoService;

@Controller
@RequestMapping("/admin")
public class AdminProductoController {

    @Autowired
    private IProductoService productoServ;

    @GetMapping("/productos")
    public String listarProductos(Model model,
                                @RequestParam(required = false) String mensaje,
                                @RequestParam(required = false) Boolean exito) {

        model.addAttribute("productos", productoServ.getProductos());
        model.addAttribute("nuevoProducto", new Producto());
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("exito", exito);
        return "admin/productos";
    }

    @PostMapping("/productos/crear")
    public String crearProducto(@ModelAttribute Producto producto) {
        try {
            productoServ.saveProducto(producto);
            return "redirect:/admin/productos?mensaje=Producto creado correctamente&exito=true";
        } catch (Exception e) {
            return "redirect:/admin/productos?mensaje=Error al crear producto&exito=false";
        }
    }

    @GetMapping("/productos/eliminar/{id}")
    public String eliminarProducto(@PathVariable Long id) {
        try {
            productoServ.deleteProducto(id);
            return "redirect:/admin/productos?mensaje=Producto eliminado&exito=true";
        } catch (Exception e) {
            return "redirect:/admin/productos?mensaje=Error al eliminar&exito=false";
        }
    }

    @GetMapping("/productos/editar/{id}")
    public String editarProductoForm(@PathVariable Long id, Model model) {
        model.addAttribute("producto", productoServ.findProducto(id));
        return "admin/editarProducto";
    }

    @PostMapping("/productos/editar/{id}")
    public String editarProducto(@PathVariable Long id,
                                @ModelAttribute Producto productoActualizado) {
        try {
            productoServ.editProducto(id, productoActualizado);
            return "redirect:/admin/productos?mensaje=Producto modificado correctamente&exito=true";
        } catch (Exception e) {
            return "redirect:/admin/productos?mensaje=Error al modificar&exito=false";
        }
    }
}