package ar.edu.centro8.daw.tif_version12.controller;

import ar.edu.centro8.daw.tif_version12.model.Factura;
import ar.edu.centro8.daw.tif_version12.service.IFacturaService;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/facturas")
public class FacturaController {

    @Autowired
    private IFacturaService facturaServ;

    @GetMapping("/traer")
    public List<Factura> getFacturas() {
        return facturaServ.getFacturas();
    }

    @GetMapping("/traer/{id}")
    public Factura getFactura(@PathVariable Long id) {
        return facturaServ.findFactura(id);
    }

    @PostMapping("/crear")
    public String saveFactura(@Valid @RequestBody Factura factura) {
        facturaServ.saveFactura(factura);
        return "Se guardó correctamente el registro de la factura ingresada.";
    }
}