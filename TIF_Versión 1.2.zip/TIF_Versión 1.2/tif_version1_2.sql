-- Active: 1762529848185@@127.0.0.1@3306@mysql

CREATE DATABASE tif_version1_2;

DROP DATABASE tif_version1_2;

USE tif_version1_2;

SELECT * FROM productos;
SELECT * FROM clientes;
SELECT * FROM facturas;
SELECT * FROM detalle_factura;